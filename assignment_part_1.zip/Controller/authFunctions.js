const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
require ('dotenv').config()
const Member = require("../Database/member");  

const memberSignup = async (req,role , res) => {
    try{
        var username = req.username
        let password = req.password
        var email = req.email

        // ensure no empty details
        if (username.trim() === "" || password.trim() === "" || email.trim() === "") {
            return res.status(404).json({
                message: "Please fill up all the details."
            });
        }

        // ensure proper email format
        const emailRegex =/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
        if (! emailRegex) {
                    return res.status(400).json({
                        message: "Invalid email format"
                    });
                }

        
        let usernameNotTaken = await validateMemberName(req.username);
        console.log(usernameNotTaken)
        if(!usernameNotTaken){
            return res.status(400).json({
                Message: 'Member is already registered with this username.'
            });
        }

        let emailNotRegistered = await validateEmail(req.email);
        if(!emailNotRegistered){
            return res.status(400).json({
                Message: 'Email is already registered'
            });
        }
        
    
        password = await bcrypt.hash(req.password , 12);
        const  newMember = new Member ({
            ...req,
            password,
            role
        })  

        await newMember.save();
        return res.status(201).json({
            message: 'you are now successfully registered please login!'
        });

    } catch (err){
        return res.status(500).json({
            message:`${err.message}`
        });
    }
};


const validateMemberName = async username => {
    let member = await Member.findOne({username});
    console.log(username)
    return member ? false : true;
};


const validateEmail = async email => {
    let member = await Member.findOne({email});
    
    return member ? false : true;
};



 //to login member (admin , public , teacher , student)


const memberLogin = async(req, role , res) => {
    let {username , password} = req;
    console.log(username , password);
    const member = await Member.findOne({username});


    // ensure no empty details
    if (username.trim() === "" || password.trim() === "") {
        return res.status(404).json({
            message: "Please make sure that everything is filled up."
        });
    }


    if (!member) {
        return res.status(400).json({
            message: "Username is not found. Invalid login credentials"
        });
    }


    // checking the role
    if(member.role !== role){
        return res.status(403).json({
            message: "Please make sure you are loggin in from the right role"
        });
    }

    // now check for password
    let isMatch = await bcrypt.compare (password , member.password);
    if (isMatch){
        let token = jwt.sign(
            {
                role : member.role,
                username : member.username,
                email: member.email
            },
            process.env.APP_SECRET,
            {expiresIn: "3 days"}
        );

        let result = {
            username: member.username,
            role: member.role,
            email: member.email,
            token: token,
            
            expiresIn: 168
        };


        return res.status(200).json({
            ...result,
            message: 'You are now logged in.'
        });
    }else{
        return res.status(403).json({
            message: "Incorrect username or password."
        });
    }
};


const memberAuth = (req, res, next) => {
    const authHeader = req.headers["authorization"];
    if(!authHeader) return res.status(403).json({
        message: "Missing Token"
    });
    const token = authHeader.split(" ")[1];

    jwt.verify(token, process.env.APP_SECRET,(err, decoded) => {
        if(err) return res.status(403).json({
            message: "Wrong Token"
        });
        console.log("printing from memberAuth func" , decoded.username);
        req.username = decoded.username;
        next();
    });
}


const checkRole = roles => async (req,res,next) =>{
    let {username} = req;
    const member = await Member.findOne({username});
    !roles.includes(member.role)
        ? res.status(401).json('Sorry you do not have access to this route')
        : next();
}

module.exports ={
    memberSignup,
    memberLogin,
    checkRole,
    memberAuth
};
