const router = require('express').Router();
const {
    memberSignup , memberLogin , memberAuth , checkRole
} = require('../Controller/authFunctions');

//admin registration route

router.post("/register-admin" , (req,res) => {
    memberSignup(req.body , "admin" , res);
});

// public registration route

router.post("/register-public" , async (req,res) => {
    memberSignup(req.body , "public" , res);
});


// teacher registration route 

router.post("/register-teacher" , async (req,res) => {
    memberSignup(req.body , "teacher" , res);
});

//student registration route 

router.post("/register-student" , async (req,res) => {
    memberSignup(req.body , "student" , res);
});




// admin login route

router.post("/login-admin", async (req,res) => {
    await memberLogin(req.body , "admin" , res);
});


// public login route
router.post("/login-public", async (req,res) => {
    await memberLogin(req.body , "public" , res);
});



// teacher login route

router.post("/login-teacher", async (req,res) => {
    await memberLogin(req.body , "teacher" , res);
});



//student login route

router.post("/login-student", async (req,res) => {
    await memberLogin(req.body , "student" , res);
});


// public unprotected route

router.get(
    "/public" , (req,res) => {
        return res.status(200).json('Public Domain');
    });


//admin protected route

router.get(
    "/admin-protected" ,
    memberAuth,
    checkRole(['admin']),
    async (req,res) => {
        return res.json(`welcome ${req.username}`)
    }
);

// general public protected route
router.get(
    "/public-protected" ,
    memberAuth,
    checkRole(['public']),
    async (req,res) => {
        return res.json(`welcome ${req.username}`)
    }
);

// Teacher protected route

router.get(
    "/teacher-protected" ,
    memberAuth,
    checkRole(['teacher']),
    async (req,res) => {
        return res.json(`welcome ${req.username}`)
    }
);

// student protected route

router.get(
    "/student-protected" ,
    memberAuth,
    checkRole(['student']),
    async (req,res) => {
        return res.json(`welcome ${req.username}`)
    }
);
module.exports = router;